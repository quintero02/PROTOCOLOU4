export async function getAll() {
  const res = await fetch('http://localhost:4000/products');
  return await res.json();
}
