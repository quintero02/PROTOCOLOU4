# CRUD Angular, Vue y React – Comparación Técnica

Repo base con proyectos de ejemplo (esqueleto) y API Node + Express.

Carpetas:
- /api
- /angular-crud
- /vue-crud
- /react-crud
